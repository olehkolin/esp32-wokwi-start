// Miganie diodą bez delay() (millis)
// LED: GPIO 2 -> rezystor 220 Ω -> anoda LED, katoda -> GND

const int LED = 2;
const unsigned long INTERVAL = 500;  // ms
unsigned long prev = 0;
bool state = false;

void setup() {
  Serial.begin(115200);
  pinMode(LED, OUTPUT);
  Serial.println("Blink bez delay() - start");
}

void loop() {
  if (millis() - prev >= INTERVAL) {  // odporne na przepełnienie millis()
    prev = millis();
    state = !state;
    digitalWrite(LED, state);
  }
}
