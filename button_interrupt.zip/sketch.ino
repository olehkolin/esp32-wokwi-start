// Przycisk + przerwanie (interrupt) + debouncing
// Przycisk: GPIO 4 <-> GND (wewnętrzny pull-up), LED na GPIO 2

const int BTN = 4;
const int LED = 2;

volatile bool pressed = false;
volatile unsigned long lastIrq = 0;

void IRAM_ATTR onPress() {          // ISR: krótko, tylko flaga
  unsigned long now = millis();
  if (now - lastIrq > 200) {        // filtr drgań styków
    pressed = true;
    lastIrq = now;
  }
}

bool ledOn = false;

void setup() {
  Serial.begin(115200);
  pinMode(LED, OUTPUT);
  pinMode(BTN, INPUT_PULLUP);       // nie wciśnięty = HIGH
  attachInterrupt(digitalPinToInterrupt(BTN), onPress, FALLING);
  Serial.println("Wcisnij przycisk");
}

void loop() {
  if (pressed) {
    pressed = false;
    ledOn = !ledOn;
    digitalWrite(LED, ledOn);
    Serial.println(ledOn ? "LED ON" : "LED OFF");
  }
}
